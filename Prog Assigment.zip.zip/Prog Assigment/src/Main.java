
public class main{
    public static void main (String[]args){
        Employee emp = new Employee("John Doe", 30 , 50000");
        Employee.setSalary(55000);
        System.out.println("Employee info" + Employee.getSalary()+"," + Employee.getAge());
    }
}
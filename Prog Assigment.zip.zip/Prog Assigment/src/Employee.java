public class Employee {
    public class Main {
        private String name;
        private final int age;
        private final double salary;

        //Constrcutor
        public Main(String name, int age, double salary) {
            this.name = name;
            this.age = age;
            this.salary = salary;
        }

        // get and set
        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        public double getSalary() {
            return salary;
        }

        public void setAge(int age){
            if(age>18){
                this.age = age;
            }
        }
        public void double getSalary
            this.salary = salary;
    }
}public class Main {
    private String name;
    private final int age;
    private final double salary;

    //Constrcutor
    public Main(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    // get and set
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    public void setAge(int age){
        if(age>18){
            this.age = age;
        }
    }
    public void double getSalary
            this.salary = salary;
}
}
}
